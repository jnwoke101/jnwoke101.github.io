# Windows 11 STIG internship lab — updated 10-script package

## What is fixed vs. what remains unresolved
- `WN11-AU-000505`: corrected Security Event Log **MaxSize = 5120000 KB** (REG_DWORD). The user's exported Tenable audit (`Windows 11 V2R9`) specified this numeric minimum; retain evidence of its passing final scan. This setting still needs to be sized for the actual one-week audit volume in real deployments.
- `WN11-AU-000150`, `WN11-AU-000555`, `WN11-AU-000560`: `auditpol.exe` scripts correctly set the required EFFECTIVE directions when executed, but on the user's VM **Group Policy refresh and Windows restart revert them to No Auditing**. Do not describe these scripts as persistent fixes.
- The other six registry controls were reported Passed by the user in Tenable after automated remediation.
- Do not use this as a production baseline or publish any claim that a transient audit change is restart-persistent.

## Included files
- `Run-All-10-STIGs.ps1`: runs seven registry STIGs first, three auditpol STIGs last. `-AuditOnly` runs the three audit changes; `-ListOnly` previews target IDs.
- Ten individual `WN11-*.ps1` scripts to place into the internship's per-STIG remediation template.
- `Verify-10-Current-State.ps1`: read-only checks of the current values.

## Execution on isolated internship VM
1. Save the failed baseline and prior manual scan evidence; do not repeat rollback now.
2. Extract the whole zip into ONE folder on Windows 11. Open Windows PowerShell ISE as Administrator (64-bit).
3. Open `Run-All-10-STIGs.ps1`, then in the BLUE console run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
& $psISE.CurrentFile.FullPath -ListOnly
& $psISE.CurrentFile.FullPath
```

4. **Do not restart or run `gpupdate /force`** if you are intentionally checking the already observed temporary audit configuration. Run read-only verification:

```powershell
& (Join-Path (Split-Path $psISE.CurrentFile.FullPath) 'Verify-10-Current-State.ps1')
```

5. Run the Tenable compliance scan while the effective settings still match the STIGs; save the results. A Passed scan shows compliance only at the instant checked and does not prove restart persistence. Explicitly document the audit GPO conflict. To remediate persistently, investigate the source of policy reset and configure a governing Local/Domain GPO. `auditpol /set` alone cannot override a higher priority GPO.

## Selected IDs
WN11-AU-000505, WN11-AU-000510, WN11-AU-000150, WN11-AU-000555, WN11-AU-000560, WN11-CC-000010, WN11-CC-000305, WN11-CC-000175, WN11-CC-000120, WN11-CC-000270.

## Notes
- A local `OK` means only that a command completed and the current local state matches the script's check; it is not a substitute for a Tenable Passed result.
- Keep VM backups and raw audit exports private. Use only on a designated, isolated lab VM.
