﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<# Read-only local verifier; does not apply or repair any settings. #>
$ErrorActionPreference='Stop'
Write-Host '=== Windows 11 STIG: local configuration (Tenable pending) ===' -ForegroundColor Cyan
$registry = @(
    @{ID='WN11-AU-000505'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\Security'; Name='MaxSize'; Value=[int64]5120000},
    @{ID='WN11-AU-000510'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\EventLog\System'; Name='MaxSize'; Value=[int64]32768},
    @{ID='WN11-CC-000010'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization'; Name='NoLockScreenSlideshow'; Value=[int64]1},
    @{ID='WN11-CC-000305'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search'; Name='AllowIndexingEncryptedStoresOrItems'; Value=[int64]0},
    @{ID='WN11-CC-000175'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat'; Name='DisableInventory'; Value=[int64]1},
    @{ID='WN11-CC-000120'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'; Name='DontDisplayNetworkSelectionUI'; Value=[int64]1},
    @{ID='WN11-CC-000270'; Path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'; Name='DisablePasswordSaving'; Value=[int64]1}
)
foreach ($r in $registry) {
    $status = 'MISSING'
    if (Test-Path -LiteralPath $r.Path) {
        $key = Get-Item -LiteralPath $r.Path
        if ($null -ne $key.GetValue($r.Name, $null)) {
            $v = [int64]$key.GetValue($r.Name)
            $kind = $key.GetValueKind($r.Name)
            $status = if ($kind -eq [Microsoft.Win32.RegistryValueKind]::DWord -and $v -ge $r.Value) { 'LOCAL OK' } else { 'LOCAL FAILED' }
            $status += " ($v, $kind)"
        }
    }
    Write-Host "$($r.ID) $status"
}
foreach ($a in @(
    @{ID='WN11-AU-000150'; Name='Security System Extension'; Direction='Success'},
    @{ID='WN11-AU-000555'; Name='Other Policy Change Events'; Direction='Failure'},
    @{ID='WN11-AU-000560'; Name='Other Logon/Logoff Events'; Direction='Success'}
)) {
    Write-Host "`n=== $($a.ID); expected $($a.Direction) ===" -ForegroundColor Cyan
    & "$env:SystemRoot\System32\auditpol.exe" /get "/subcategory:$($a.Name)"
    if ($LASTEXITCODE -ne 0) { Write-Warning "auditpol query failed for $($a.ID)" }
}
