﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
STIG: WN11-CC-000175
Description: Disable Inventory Collector
Scope: Windows 11 internship LAB ONLY. Use after preserving the failing scan.
Expected registry: HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat\DisableInventory = 1 (REG_DWORD)
Local validation is not a Tenable compliance result.
#>
$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitProcess) { throw 'Use 64-bit Windows PowerShell as Administrator.' }
$stig = 'WN11-CC-000175'
$path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat'
$name = 'DisableInventory'
$required = [int64]1
if (-not (Test-Path -LiteralPath $path)) {
    New-Item -Path $path -Force | Out-Null
}
New-ItemProperty -LiteralPath $path -Name $name -PropertyType DWord -Value ([int]$required) -Force | Out-Null
$key = Get-Item -LiteralPath $path
$actual = [int64]$key.GetValue($name)
$kind = $key.GetValueKind($name)
if ($kind -ne [Microsoft.Win32.RegistryValueKind]::DWord -or $actual -lt $required) {
    throw "$WN11-CC-000175: local verification failed ($name=$actual, type=$kind; required >= $required REG_DWORD)."
}
Write-Host "[LOCAL OK] $stig : $name=$actual ($kind); Tenable verification pending." -ForegroundColor Green
