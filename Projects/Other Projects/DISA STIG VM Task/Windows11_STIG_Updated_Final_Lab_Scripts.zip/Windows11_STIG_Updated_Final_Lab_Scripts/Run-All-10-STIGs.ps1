﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
Windows 11 STIG Internship Lab - FINAL IN-SESSION BATCH RUNNER
Seven registry remediations are applied first. Three auditpol remediations are applied LAST.
The three auditpol controls are known to reset on this VM after gpupdate /force or restart.
Do not claim a lasting fix or a Passed Tenable finding from local script output.
#>
[CmdletBinding()]
param([switch]$ListOnly, [switch]$AuditOnly)
$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitProcess) { throw 'Run 64-bit Windows PowerShell as Administrator.' }
if (-not $PSScriptRoot) { throw 'Save the script and keep it with the individual .ps1 files.' }
$registryIds = @(
    'WN11-AU-000505',
    'WN11-AU-000510',
    'WN11-CC-000010',
    'WN11-CC-000305',
    'WN11-CC-000175',
    'WN11-CC-000120',
    'WN11-CC-000270'
)
$auditIds = @(
    'WN11-AU-000150',
    'WN11-AU-000555',
    'WN11-AU-000560'
)
$ids = if ($AuditOnly) { $auditIds } else { @($registryIds) + @($auditIds) }
$missing = @($ids | Where-Object { -not (Test-Path -LiteralPath (Join-Path $PSScriptRoot "$_.ps1") -PathType Leaf) })
if ($missing.Count) { throw "Missing files: $($missing -join ', '); extract all ZIP contents together." }
if ($ListOnly) { $ids | ForEach-Object { Write-Host $_ }; return }
$results = @()
foreach ($id in $ids) {
    Write-Host "`n=== $id ===" -ForegroundColor Cyan
    try {
        & (Join-Path $PSScriptRoot "$id.ps1")
        $results += [pscustomobject]@{ STIG=$id; LocalStatus='OK' }
    } catch {
        Write-Warning "${id}: $($_.Exception.Message)"
        $results += [pscustomobject]@{ STIG=$id; LocalStatus='FAILED' }
    }
}
Write-Host "`n=== CURRENT LOCAL RESULTS (not Tenable results) ===" -ForegroundColor Cyan
$results | Format-Table -AutoSize | Out-Host
$failures = @($results | Where-Object LocalStatus -eq 'FAILED')
if ($failures.Count) { throw "$($failures.Count) local remediation(s) failed." }
Write-Host "All $($ids.Count) local remediations report OK." -ForegroundColor Green
Write-Warning 'For this VM, Security System Extension, Other Policy Change Events, and Other Logon/Logoff Events revert to No Auditing on gpupdate/restart. These are NOT persistent fixes.'
Write-Warning 'If verifying this temporary state in Tenable, launch the scan without restarting or refreshing Group Policy. Document the limitation in the internship report.'
