﻿#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
STIG: WN11-AU-000555
Requirement: Failure auditing for Other Policy Change Events.
Changes the EFFECTIVE audit policy using auditpol.exe.
IMPORTANT: On this user's lab VM, gpupdate /force and VM restart reset this to No Auditing.
This file is a working in-session remediation, NOT a persistent Group Policy fix.
Do not claim restart persistence unless separately confirmed. Tenable must verify compliance.
#>
$ErrorActionPreference = 'Stop'
if (-not [Environment]::Is64BitProcess) { throw 'Use 64-bit Windows PowerShell as Administrator.' }
$stig = 'WN11-AU-000555'
$subcategory = 'Other Policy Change Events'
$auditpol = Join-Path $env:SystemRoot 'System32\auditpol.exe'
$setOutput = @(& $auditpol /set "/subcategory:$subcategory" '/failure:enable' 2>&1)
if ($LASTEXITCODE -ne 0) { throw "$stig auditpol /set failed: $($setOutput -join '; ')" }
$lines = @(& $auditpol /get "/subcategory:$subcategory" 2>&1)
if ($LASTEXITCODE -ne 0) { throw "$stig auditpol /get failed: $($lines -join '; ')" }
$lines | Out-Host
$pattern = '(?im)^\s*' + [regex]::Escape($subcategory) + '\s+([^\r\n]+)'
$match = [regex]::Match(($lines -join "`n"), $pattern)
if (-not $match.Success -or $match.Groups[1].Value -notmatch '(?i)\bFailure\b') {
    throw "$stig local verification failed; expected Failure auditing."
}
Write-Host '[LOCAL OK] WN11-AU-000555 - Failure auditing active NOW. May reset at policy refresh/restart; Tenable pending.' -ForegroundColor Yellow
